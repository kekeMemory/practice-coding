#include <cstdio>
#include <cstring>
#include "point.h"
using namespace std;

struct POINT point;
int main(){
    point.x = 10;
    point.y = 20;
    
    return 0;
}


